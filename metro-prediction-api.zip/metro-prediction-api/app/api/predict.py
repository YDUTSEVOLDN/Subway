from datetime import datetime
from flask import Blueprint, request, jsonify
from app import current_app
from models import metro_data

metro_bp = Blueprint('metro', __name__, url_prefix='/metro')

@metro_bp.route('/predict', methods=['POST'])
def predict_metro_traffic():
    """地铁流量预测API端点"""
    data = request.json

    # 参数解析
    start_date = datetime.strptime(data['start_date'], '%Y-%m-%d').date()
    end_date = datetime.strptime(data['end_date'], '%Y-%m-%d').date()
    stations = data.get('stations')  # 可选站点列表

    try:
        # 执行批量预测 [6](@ref)
        result = current_app.prediction_service.batch_predict(start_date, end_date, stations)
        return jsonify({
            'status': 'success',
            'predicted_records': result,
            'message': f'成功生成{result}条预测记录'
        }), 200
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

@metro_bp.route('/predict/single', methods=['POST'])
def predict_single_record():
    """单条数据预测API"""
    data = request.json

    # 创建临时数据对象
    record = metro_data(
        date=datetime.strptime(data['date'], '%Y-%m-%d').date(),
        station=data['station'],
        district=data['district'],
        time_slot=datetime.strptime(data['time_slot'], '%H:%M').time(),
        is_transfer=data.get('is_transfer', 0),
        temperature=data.get('temperature'),
        humidity=data.get('humidity'),
        wind_speed=data.get('wind_speed')
    )

    try:
        result = current_app.prediction_service.predict_single(record)
        return jsonify({
            'status': 'success',
            'prediction': result
        }), 200
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500