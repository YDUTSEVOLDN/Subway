from flask import Blueprint
from app.models.metro_data import MetroHistoricalData
from app.models.predict_data import MetroPredictionData
bp = Blueprint('api', __name__)

# 导入路由模块
from app.api import metro