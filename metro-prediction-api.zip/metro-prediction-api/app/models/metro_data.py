# app/extensions.py
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS

db = SQLAlchemy()
cors = CORS()

# ================================================================
# 3. 修复 models/metro_data.py - 从 extensions 导入 db
# ================================================================

# models/metro_data.py
from extensions import db
from sqlalchemy import Column, Integer, String, Float, Date, Time, DateTime
from datetime import datetime

class MetroHistoricalData(db.Model):
    __tablename__ = 'metro_historical_data'
    
    id = Column(Integer, primary_key=True)
    date = Column(Date, nullable=False)
    station = Column(String(100), nullable=False)
    district = Column(String(50), nullable=False)
    time = Column(Time, nullable=False)
    in_count = Column(Float, nullable=False)
    out_count = Column(Float, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<MetroHistoricalData {self.station} {self.date} {self.time}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'date': self.date.isoformat() if self.date else None,
            'station': self.station,
            'district': self.district,
            'time': self.time.isoformat() if self.time else None,
            'in_count': self.in_count,
            'out_count': self.out_count,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
